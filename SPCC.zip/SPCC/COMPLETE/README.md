# Practical

## SPCC Practical
https://docs.google.com/document/d/1s2TfSQzu-rNoNPmJFhbOrGXgOPsYcWlYE71Yxg05GJQ/edit?usp=drivesdk

https://github.com/namanagarwal3112/SPCC
