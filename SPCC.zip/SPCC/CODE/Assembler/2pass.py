import pandas as pd
print()
print()
f = open("C:/Users/Siddharth/OneDrive/Desktop/SPCC/practical-main/Exp Wise Code/exp3 OnePass and TwoPass Assembler/SPCC1.txt", "r")
n = 0
lines = []
ads = ['START', 'END', 'USING', 'DROP', 'DC', 'DS']
adsAddress = ['P1 START', 'P1 END', 'P1 USING', 'P1 DROP', 'P1 DC', 'P1 DS']
for l in f:
    n = n+1
    lines.append(l)
instructions = []
for l in lines:
    instructions.append(l.strip().split())


def generateInstruction(opcode, binOpcode, length, mode):
    instruction = [opcode, binOpcode, length, mode]
    return instruction


def isLiteral(i):
    if (i.find("F'") == -1 or i.find("H'") == -1):
        return False
    else:
        return True


def getValueAndSize(i):
    idx = i.find("F'")
    if (idx != -1):
        val = int(i[idx+2:-1])
        return val, 4
    else:
        idx = i.find("H'")
        if (idx != -1):
            val = int(i[idx+2:-1])
            return val, 2
        else:
            return 0, 0


def getSTIdx(s, st):
    i = 0
    for j in st:
        if (s == j[0]):
            return i
        else:
            i = i+1
    return -1


def performPassOne(instructions):
    mot = []
    st = []
    lt = []
    lc = [0]
    op1 = []
    symbols = []
    opcodes = []
    arguments = []
    for i in instructions:
        if (len(i) == 1):
            lc.append(lc[-1])
            op1.append("-")
            symbols.append("-")
            opcodes.append(i[0])
            arguments.append("-")

        if (len(i) == 3):
            if (i[1].upper() == 'START'):
                lc.append(int(i[2]))
                mode = "R"
                if (int(i[2]) != 0):
                    mode = "A"
                st.append([i[0], i[2], 1, mode])
                op1.append("-")

            else:
                if (i[1].upper() == 'DC'):
                    symbol = i[0]
                    value, size = getValueAndSize(i[2])
                    mode = "R"
                    st.append([i[0], lc[-1], size, mode])
                    lt.append([i[2], lc[-1], size, mode])
                    lc.append(lc[-1] + size)
                    op1.append(value)
                else:
                    lc.append(lc[-1])
                    st.append([i[0], lc[-1], size, mode])
                    op1.append("-")
                symbols.append(i[0])
                opcodes.append(i[1])
                arguments.append(i[2])

        if (len(i) == 2):
            if (i[0] not in ads):
                if (i[0].find("R") != -1):
                    instruction = generateInstruction(i[0], "-", 2, "000")
                    mot.append(instruction)
                    lc.append(lc[-1] + 2)
                    operands = i[1].split(",")
                    if (not isLiteral(operands[1])):
                        operands[1] = "-"
                    operands = ",".join(operands)
                    op_inst = " ".join([i[0], operands])
                    op1.append(op_inst)
                else:
                    instruction = generateInstruction(i[0], "-", 4, "001")
                    mot.append(instruction)
                    lc.append(lc[-1] + 4)
                    operands = i[1].split(",")
                    if (not isLiteral(operands[1])):
                        operands[1] = "-"
                    operands = ",".join(operands)
                    op_inst = " ".join([i[0], operands])
                    op1.append(op_inst)
            else:
                lc.append(lc[-1])
                op1.append("-")
            symbols.append("-")
            opcodes.append(i[0])
            arguments.append(i[1])

    firstPass = pd.DataFrame(list(zip(lc, op1)), columns=[
                             'Relative Address', 'Mnemonic'])
    motpd = pd.DataFrame(
        mot, columns=['Opcode', 'Binary Opcode', 'Length', 'Format'])
    ltpd = pd.DataFrame(
        lt, columns=['Literal', 'Value', 'Length', 'Relocation'])
    stpd = pd.DataFrame(
        st, columns=['Symbol', 'Value', 'Length', 'Relocation'])
    potpd = pd.DataFrame(list(zip(ads, adsAddress)), columns=[
                         'Pseudo Opcode', 'Address'])

    print("MOT: ")
    print(motpd)
    print("\n")
    print("POT: ")
    print(potpd)
    print("\n")
    print("LT: ")
    print(ltpd)
    print("\n")
    print("ST: ")
    print(stpd)
    print("\n")
    print("Output of PASS 1: ")
    print(firstPass)

    performPassTwo(instructions, lc, mot, lt, st,
                   op1, symbols, opcodes, arguments)


def performPassTwo(instructions, lc, mot, lt, st, op1, symbols, opcodes, arguments):
    bt = []
    br = []
    op2 = []
    for i in instructions:
        if (len(i) == 1):
            op2.append("-")

        if (len(i) == 3):
            if (i[1].upper() == 'START'):
                op2.append("-")
            else:
                if (i[1].upper() == 'DC'):
                    symbol = i[0]
                    value, size = getValueAndSize(i[2])
                    mode = "R"
                    st.append([i[0], lc[-1], size, mode])
                    lt.append([i[2], lc[-1], size, mode])
                    lc.append(lc[-1] + size)
                    op2.append(value)
                else:
                    lc.append(lc[-1])
                    st.append([i[0], lc[-1], size, mode])
                    op2.append("-")

        if (len(i) == 2):
            if (i[0] not in ads):
                if (i[0].find("R") != -1):
                    print(i[0]+" RR Format")
                    instruction = generateInstruction(i[0], "", 2, "000")
                    mot.append(instruction)
                    lc.append(lc[-1] + 2)
                    operands = i[1].split(",")
                    if (not isLiteral(operands[1])):
                        operands[1] = "-"
                    operands = ",".join(operands)
                    op_inst = " ".join([i[0], operands])
                    op1.append(op_inst)

                else:
                    operands = i[1].split(",")
                    idx = getSTIdx(operands[1], st)

                    if (idx != -1):
                        value = st[idx][1]
                        base = 0
                        if (len(br) > 0):
                            base = br[0]
                        operands[1] = str(value) + "(0," + str(base) + ")"
                        operands = ",".join(operands)
                        op_inst = " ".join([i[0], operands])
                        op2.append(op_inst)

            else:
                lc.append(lc[-1])
                op2.append("-")

                if (i[0] == "USING"):
                    operands = i[1].split(",")
                    idx = getSTIdx(operands[1], st)
                    if (idx == -1):
                        if (not isLiteral(operands[1])):
                            value = int(operands[1])
                            br.append(value)
                        else:
                            value, size = getValueAndSize(operands[1])

                    else:
                        br.append(st[idx][1])

    for i in range(0, 16):
        if (i in br):
            bt.append([i, "Y", 00])
        else:
            bt.append([i, "N", 00])

    secondPass = pd.DataFrame(list(zip(lc, op2)), columns=[
                              'Relative Address', 'Mnemonic'])
    btpd = pd.DataFrame(bt, columns=['Register', 'Availability', 'Contents'])

    print("BT: ")
    print(btpd)
    print()
    print("Output of PASS 2: ")
    print(secondPass)
    print()
    print("Result: ")
    output = pd.DataFrame(list(zip(symbols, opcodes, arguments, lc, op1, op2)),
                          columns=['Symbol', 'Opcode', 'Operand', 'Relative Address', 'PASS 1', 'PASS 2'])
    print(output)
    print()
    print()


performPassOne(instructions)

'''
MOT: 
  Opcode Binary Opcode  Length Format
0      L             -       4    001
1      A             -       4    001
2     ST             -       4    001


POT: 
  Pseudo Opcode   Address
0         START  P1 START
1           END    P1 END
2         USING  P1 USING
3          DROP   P1 DROP
4            DC     P1 DC
5            DS     P1 DS


LT:
  Literal  Value  Length Relocation
0    F'4'     12       4          R
1    F'5'     16       4          R


ST:
  Symbol Value  Length Relocation
0     Ni     0       1          R
1   FOUR    12       4          R
2   FIVE    16       4          R
3   TEMP    20       4          R


Output of PASS 1:
   Relative Address Mnemonic
0                 0        -
1                 0        -
2                 0    L 1,-
3                 4    A 1,-
4                 8   ST 1,-
5                12        4
6                16        5
7                20        -
8                20        -
BT: 
    Register Availability  Contents
0          0            N         0
1          1            N         0
2          2            N         0
3          3            N         0
4          4            N         0
5          5            N         0
6          6            N         0
7          7            N         0
8          8            N         0
9          9            N         0
10        10            N         0
11        11            N         0
12        12            N         0
13        13            N         0
14        14            N         0
15        15            Y         0

Output of PASS 2:
   Relative Address       Mnemonic
0                 0              -
1                 0              -
2                 0   L 1,16(0,15)
3                 4   A 1,12(0,15)
4                 8  ST 1,20(0,15)
5                12              4
6                16              5
7                20              -
8                20              -

Result:
  Symbol Opcode Operand  Relative Address  PASS 1         PASS 2
0      -  USING    *,15                 0       -              -
1      -      L  1,FIVE                 0       -              -
2      -      A  1,FOUR                 0   L 1,-   L 1,16(0,15)
3      -     ST  1,TEMP                 4   A 1,-   A 1,12(0,15)
4   FOUR     DC    F'4'                 8  ST 1,-  ST 1,20(0,15)
5   FIVE     DC    F'5'                12       4              4
6   TEMP     DS    1'F'                16       5              5
7      -    END       -                20       -              -
'''




'''
Features of writin program in assembly:
    Mnemonic opcode specification:
        Assembly language uses mnemonic codes, which are human-readable abbreviations for machine language instructions. Instead of writing the actual binary code, programmers can write a simple abbreviation, making it easier to read and understand the code. For example, instead of writing the binary code for loading data into a register, the assembly language instruction might be written as "LDR R0, [R1]". The assembler then translates this into the binary code that the computer can understand.

    Symbolic Operand Specification:
        In assembly language, instead of referring to data or instructions by their memory addresses, programmers can use symbolic names or labels. For example, instead of writing the memory address for a specific data item, a programmer might give it a name like "myData". The assembler then replaces the symbolic name with the actual memory address, making the code more readable and easier to understand.

    Storage Area specification:
        Assembly language allows programmers to declare data and storage areas within the code. This means that they can reserve a specific part of the computer's memory for storing data or instructions. For example, a programmer might reserve a block of memory to store an array of data or to hold the code for a subroutine. This allows the programmer to organize the code and data more efficiently, and makes it easier to access and manipulate that data. eg: using START 100 specifies the program to start from memory location 100

Types of Statement in ALP:
Assembly language code consists of different types of statements:
    Imperative statements that are executed by the computer eg ADD SUB MUL
    Declarative statements that declare data, and assembler eg MY_VAR DC 10
    Directive statements that direct the assembler to perform specific tasks.eg START STOP/HALT

Why use two pass assembler:
    The forward reference problem (FRP) occurs when a reference is made to a symbol before it is defined in the assembly code. This problem arises because the rules of the assembly language require symbols to be defined before they can be used.

    FRP can cause issues for the assembler because it needs to replace each symbol with its machine code address, and if it comes across a symbol before it is defined, it won't know the address to replace it with.

    The solution to FRP is to make two passes over the assembly code. In the first pass, the assembler keeps track of the location counter (LC), determines the length of machine instructions, remembers the values of symbols until pass 2, and processes some pseudo-ops such as EQU, DS, and DC. The assembler also remembers literals.

    In the second pass, the assembler looks up the values of symbols, generates instructions and data, and processes some pseudo-ops such as USING and DROP. By making two passes, the assembler can resolve any forward references that it comes across in the first pass.
'''