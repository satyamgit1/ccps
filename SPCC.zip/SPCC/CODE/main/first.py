def compute_first_sets(grammar):
    first_set = {}
    non_ter_arr = []
    for i in grammar:
        first_set[i] = []
        non_ter_arr.append(i)

    
    for i in range(len(non_ter_arr)-1, -1, -1):
        NT = non_ter_arr[i]
        find_first(NT, grammar, first_set)

    
    for i in first_set:
        first_set[i] = list(set(first_set[i]))

    print(first_set)
    for i in first_set:
        print(i, first_set[i])
    print('\n')
    # return first_set




def find_first(NT, grammar, first_set):


    first_arr = []
    for i in grammar[NT]:
        if i != '':
            first_char = i[0]
        else:
            first_char = '-'
        if ((first_char >= 'a' and first_char <= 'z') or (first_char == '-')):
            first_arr.append(first_char)

        elif (first_char >= 'A' and first_char <= 'Z'):
            first_arr += first_set[first_char]
            counter = 1
            while '-' in first_set[first_char]:

                if ((first_char >= 'a' and first_char <= 'z') or (first_char == '-')) or counter == len(i):
                    break
                first_char = i[counter]
                first_arr += first_set[first_char]
                counter += 1
        

    
    first_set[NT] = first_arr



grammar1 = {
    'S': ['A'],
    'A': ['aBX'],
    'X': ['dX', '-'],
    'B': ['b'],
    'C': ['g'],
}
compute_first_sets(grammar1)


# grammar2 = {
#     'S': ['aBDh'],
#     'B': ['cC'],
#     'C': ['bC', '-'],
#     'D': ['EF'],
#     'E': ['g', '-'],
#     'F': ['f', '-'],
# }
# compute_first_sets(grammar2)