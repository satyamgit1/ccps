def compute_follow_sets(grammar):
    follow_set = {}
    for i in grammar:
        follow_set[i] = []
    follow_set['S'] = ['$']


    


    pass


grammar1 = {
    "S": ["A"],
    "A": ["aBX"],
    "X": ["dX", "-"],
    "B": ["b"],
    "C": ["g"],
}

first_sets = {
    "S": ["a"],
    "A": ["a"],
    "X": ["d", "-"],
    "B": ["b"],
    "C": ["g"],
}
compute_follow_sets(grammar1)
