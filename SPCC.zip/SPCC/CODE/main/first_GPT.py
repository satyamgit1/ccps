def compute_first_sets(grammar):
    first_sets = {}
    for nonterminal in grammar:
        first_sets[nonterminal] = set()
    changed = True
    while changed:
        changed = False
        for nonterminal, productions in grammar.items():
            for production in productions:
                if len(production) == 0:
                    first_sets[nonterminal].add('')
                elif production[0] not in grammar:
                    if production[0] not in first_sets[nonterminal]:
                        first_sets[nonterminal].add(production[0])
                        changed = True
                else:
                    i = 0
                    while i < len(production) and '' in first_sets[production[i]]:
                        first_sets[nonterminal].update(first_sets[production[i]] - {''})
                        i += 1
                    if i == len(production) or ('' in first_sets[production[i]] and i+1 == len(production)):
                        first_sets[nonterminal].add('')
                    if i < len(production) and production[i] in grammar:
                        for symbol in first_sets[production[i]]:
                            if symbol not in first_sets[nonterminal]:
                                first_sets[nonterminal].add(symbol)
                                changed = True
    return first_sets


grammar = {
    'S': ['aA', 'bB', 'c'],
    'A': ['d', ''],
    'B': ['e', '']
}

first_sets = compute_first_sets(grammar)
print(first_sets)
