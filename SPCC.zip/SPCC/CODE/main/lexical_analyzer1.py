import re


#  keyword, identifier, symbols
def lexical_analyzer(x):
    c_key_words = re.compile(r'\b(if|else|while|for|break|continue|return|int|main|)\b')
    c_symbols = re.compile( r'(\+|-|\*|/|<|>|=|;|,|\(|\)|{|}|[|]|&|&&|\|\||!|!=|==|\.)')
    c_identifier = re.compile(r'[a-zA-Z_][a-zA-Z0-9_]*')
    c_preprocessor_directives = re.compile(r'\B#\w+')
    c_number = re.compile(r'\d+')

    key_word_arr = c_key_words.findall(x)
    symbol_arr = c_symbols.findall(x)
    identifier_arr = c_identifier.findall(x)
    preprocessor_directives_arr = c_preprocessor_directives.findall(x)
    number_arr = c_number.findall(x)

    print(key_word_arr)
    print(symbol_arr)
    print(identifier_arr)
    print(preprocessor_directives_arr)
    print(number_arr)


code = """
#inclide <stdio.h>
int main(){
    int a = 10;
    return 0;
}
"""

lex_analyzer = lexical_analyzer(code)
print(lex_analyzer)