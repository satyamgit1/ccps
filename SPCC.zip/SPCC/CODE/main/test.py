import re

c_identifier = re.compile(r'[a-zA-Z_][a-zA-Z0-9_]*')

c_preprocessor_directives = re.compile(r'\B#\w+')

# string that start with #



code = '''
#include <stdio.h>
int main() {
    int x123 = 123;
    String sS = "hello";
    printf("x = %d", x);
'''

x = c_preprocessor_directives.findall(code)
print(x)