# Practical

## SPCC Practical
